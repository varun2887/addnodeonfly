#!/bin/bash

# Exit on first error, print all commands.
set -e

Usage() {
	echo ""
	echo "Usage: ./startFabric.sh [-d || --dev]"
	echo ""
	echo "Options:"
	echo -e "\t-d or --dev: (Optional) enable fabric development mode"
	echo ""
	echo "Example: ./startFabric.sh"
	echo ""
	exit 1
}

Parse_Arguments() {
	while [ $# -gt 0 ]; do
		case $1 in
			--help)
				HELPINFO=true
				;;
            --dev | -d)
				FABRIC_DEV_MODE=true
				;;
		esac
		shift
	done
}

Parse_Arguments $@

if [ "${HELPINFO}" == "true" ]; then
    Usage
fi

#Detect architecture
ARCH=`uname -m`

# Grab the current directory
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

cd "$DIR"/composer

rm -f docker-compose.yml
cp docker-compose-template.yml docker-compose.yml


    OPTS="-i"
# The next steps will replace the template's contents with the
# actual values of the private key file names for the two CAs.
CURRENT_DIR=$PWD
cd crypto-config/peerOrganizations/SYSTEMA.TRS.com/ca/
PRIV_KEY=$(ls *_sk)
cd "$CURRENT_DIR"
sed $OPTS "s/CASYSTEMA_PRIVATE_KEY/${PRIV_KEY}/g" docker-compose.yml

cd crypto-config/peerOrganizations/SYSTEMB.TRS.com/ca/
PRIV_KEY=$(ls *_sk)
cd "$CURRENT_DIR"
sed $OPTS "s/CASYSTEMB_PRIVATE_KEY/${PRIV_KEY}/g" docker-compose.yml

cd crypto-config/peerOrganizations/ROBOT.TRS.com/ca/
PRIV_KEY=$(ls *_sk)
cd "$CURRENT_DIR"
sed $OPTS "s/CAROBOT_PRIVATE_KEY/${PRIV_KEY}/g" docker-compose.yml

cd "$CURRENT_DIR"

DOCKER_FILE="${DIR}"/composer/docker-compose.yml

ARCH=$ARCH docker-compose -f "${DOCKER_FILE}" down
ARCH=$ARCH docker-compose -f "${DOCKER_FILE}" up -d

# wait for Hyperledger Fabric to start
# incase of errors when running later commands, issue export FABRIC_START_TIMEOUT=<larger number>
echo "sleeping for ${FABRIC_START_TIMEOUT} seconds to wait for fabric to complete start up"
sleep ${FABRIC_START_TIMEOUT}

echo "# Create the channel"
docker exec peer0.ROBOT.TRS.com peer channel create -o orderer.localhost:7050 -c composerchannel -f /etc/hyperledger/configtx/composer-channel.tx
echo "######################## In join channel ROBOT.TRS.com ########################"
docker exec -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@ROBOT.TRS.com/msp" peer0.ROBOT.TRS.com peer channel join -b composerchannel.block

MAX_RETRY=2
DELAY=3
COUNTER=1
joinWithRetry () {
	echo "######################## In join channel $1 ########################"
	docker exec -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@$1/msp" peer0.$1 peer channel fetch config -o orderer.localhost:7050 -c composerchannel >&log.txt
	docker exec -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@$1/msp" peer0.$1 peer channel join -b composerchannel_config.block >&log.txt
	res=$?
	cat log.txt
	if [ $res -ne 0 -a $COUNTER -lt $MAX_RETRY ]; then
		COUNTER=` expr $COUNTER + 1`
		echo "PEER$1 failed to join the channel, Retry after 2 seconds"
		sleep $DELAY
		joinWithRetry $1
	else
		COUNTER=1
	fi
 #verifyResult $res "After $MAX_RETRY attempts, PEER$ch has failed to Join the Channel"
}

for ch in "SYSTEMA.TRS.com" "SYSTEMB.TRS.com"; do
	echo 
	joinWithRetry $ch
	sleep $DELAY
	echo
done

if [ "${FABRIC_DEV_MODE}" == "true" ]; then
    echo "Fabric Network started in chaincode development mode"
fi
